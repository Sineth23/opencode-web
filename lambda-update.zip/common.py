# lambdas/common.py
from __future__ import annotations

from datetime import datetime, timezone
import base64
import json
import time
from typing import Any

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "content-type,authorization",
    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
}

_REDACT_KEY_SUBSTRINGS = (
    "token",
    "secret",
    "authorization",
    "password",
    "passwd",
    "pat",
    "api_key",
    "apikey",
    "bearer",
)

def _redact(obj: Any, *, depth: int = 0) -> Any:
    """
    Defensive redaction for logs. Never log raw secrets.
    - Redacts values for keys containing sensitive substrings.
    - Truncates very large strings/lists to keep logs sane.
    """
    if depth > 8:
        return "<redacted>"

    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            lk = str(k).lower()
            if any(s in lk for s in _REDACT_KEY_SUBSTRINGS):
                out[k] = "<redacted>"
            else:
                out[k] = _redact(v, depth=depth + 1)
        return out

    if isinstance(obj, list):
        max_items = 200
        trimmed = obj[:max_items]
        out = [_redact(x, depth=depth + 1) for x in trimmed]
        if len(obj) > max_items:
            out.append("<truncated>")
        return out

    if isinstance(obj, str):
        if len(obj) > 2000:
            return obj[:2000] + "…"
        return obj

    return obj

def audit_log(action: str, user_id: str, tenant_id: str | None, ok: bool, extra: dict | None = None) -> None:
    evt = {
        "ts": int(time.time()),
        "action": action,
        "userId": user_id,
        "tenantId": tenant_id,
        "ok": ok,
    }
    if extra:
        evt.update(_redact(extra))
    print(json.dumps(evt, ensure_ascii=False, default=str), flush=True)

def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def _json_dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, default=str)

def resp(status: int, obj: dict, *, headers: dict | None = None) -> dict:
    out_headers = {"Content-Type": "application/json"}
    out_headers.update(CORS_HEADERS)
    if headers:
        out_headers.update(headers)

    return {
        "statusCode": int(status),
        "headers": out_headers,
        "body": _json_dumps(obj),
    }

def _get_request_context(event: dict) -> dict:
    return (event.get("requestContext") or {}) if isinstance(event, dict) else {}

def get_jwt_claims(event: dict) -> dict:
    rc = _get_request_context(event)
    auth = (rc.get("authorizer") or {})
    jwt = (auth.get("jwt") or {})
    claims = (jwt.get("claims") or {})
    return claims or {}

def get_user(event: dict) -> dict:
    claims = get_jwt_claims(event)
    return {
        "userId": claims.get("sub"),
        "email": claims.get("email") or claims.get("cognito:email"),
        "username": claims.get("cognito:username") or claims.get("username"),
    }

def parse_json_body(event: dict) -> dict:
    raw = event.get("body")
    if not raw:
        return {}

    if event.get("isBase64Encoded"):
        try:
            raw = base64.b64decode(raw).decode("utf-8", errors="replace")
        except Exception:
            return {}

    try:
        return json.loads(raw) if isinstance(raw, str) else (raw or {})
    except Exception:
        return {}

def is_options(event: dict) -> bool:
    try:
        return (event.get("requestContext", {}).get("http", {}).get("method") == "OPTIONS")
    except Exception:
        return False

# ---------------------------------------------------------------------
# Milestone 4 helpers (required by status lambdas)
# ---------------------------------------------------------------------

def s3_error_category_from_code(code: str) -> str:
    c = (code or "").strip()
    if c in ("AccessDenied", "403"):
        return "EVIDENCE_ACCESS_DENIED"
    if c in ("NoSuchKey", "NotFound", "404"):
        return "EVIDENCE_NO_SUCH_KEY"
    if c in ("SlowDown", "ServiceUnavailable", "InternalError", "500"):
        return "EVIDENCE_TRANSIENT"
    if not c:
        return "EVIDENCE_READ_FAILED"
    return "EVIDENCE_READ_FAILED"

def ecs_status_category(last_status: str | None) -> str:
    s = (last_status or "").strip().upper()
    if s in ("RUNNING", "PENDING", "PROVISIONING", "ACTIVATING", "DEPROVISIONING"):
        return "RUNNING"
    if s == "STOPPED":
        return "STOPPED"
    if s:
        return "UNKNOWN"
    return "UNKNOWN"

def job_receipt_key(project_id: str, job_id: str) -> str:
    pid = (project_id or "default").strip() or "default"
    jid = (job_id or "").strip()
    return f"projects/{pid}/jobs/{jid}/_job.json"
