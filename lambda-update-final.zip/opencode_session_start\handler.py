# lambdas/opencode_session_start/handler.py
#
# Starts a per-user OpenCode session as a Fargate task.
#
# Flow:
#   1. Validate Cognito JWT -> get tenantId
#   2. Load tenant record (bucket, tenantWorkloadRoleArn)
#   3. Load the clone job record to find the repo S3 prefix
#   4. Generate a one-time session password (not stored server-side)
#   5. Launch Fargate task with enableExecuteCommand=True
#   6. Record session in JOBS_TABLE (type=opencode_session)
#   7. Return sessionId, taskArn, password, and connection instructions
#
# POST /opencode/sessions
# Body:
#   cloneJobId   (required) - jobId of a completed clone job (supplies repoPrefix)
#   projectId    (optional, default "default")
#   includePm    (optional, default true) - whether to sync PM files into /workspace/pm

from __future__ import annotations

import os
import secrets
import uuid

import boto3

from common import resp, now_iso, get_user, audit_log, parse_json_body, is_options

AWS_REGION          = os.environ.get("AWS_DEFAULT_REGION", "ca-central-1")
BUILD_ID            = os.environ.get("BUILD_ID", "unknown")

TENANTS_TABLE       = os.environ["TENANTS_TABLE"]
USER_TENANTS_TABLE  = os.environ["USER_TENANTS_TABLE"]
JOBS_TABLE          = os.environ["JOBS_TABLE"]

CLUSTER_ARN         = os.environ["CLUSTER_ARN"]
TASK_DEF_ARN_SSM_PARAM = os.environ["TASK_DEF_ARN_SSM_PARAM"]
SUBNETS             = [s.strip() for s in os.environ["SUBNETS"].split(",") if s.strip()]
SECURITY_GROUP_ID   = os.environ["SECURITY_GROUP_ID"]
CONTAINER_NAME      = os.environ.get("OPENCODE_CONTAINER_NAME", "autodoc-opencode")
BEDROCK_MODEL_ID    = os.environ.get(
    "BEDROCK_MODEL_ID",
    "arn:aws:bedrock:ca-central-1:675344693717:application-inference-profile/a7aud7uhnqkx",
)

dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
ecs_client = boto3.client("ecs", region_name=AWS_REGION)
ssm_client = boto3.client("ssm", region_name=AWS_REGION)

# Cache task def ARN per Lambda container lifetime (Gotcha #5 pattern)
_TASK_DEF_ARN_CACHE: str | None = None


def _get_task_def_arn() -> str:
    global _TASK_DEF_ARN_CACHE
    if _TASK_DEF_ARN_CACHE is None:
        _TASK_DEF_ARN_CACHE = ssm_client.get_parameter(
            Name=TASK_DEF_ARN_SSM_PARAM
        )["Parameter"]["Value"]
    return _TASK_DEF_ARN_CACHE


def _bool(v, default: bool = True) -> bool:
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in ("1", "true", "yes", "y")


def main(event, context):
    if is_options(event):
        return resp(200, {"ok": True, "buildId": BUILD_ID})

    user = get_user(event)
    if not user.get("userId"):
        audit_log("OPENCODE_SESSION_START", "anonymous", None, False, {"error": "Unauthorized"})
        return resp(401, {"ok": False, "error": "Unauthorized", "buildId": BUILD_ID})

    body = parse_json_body(event)
    clone_job_id = (body.get("cloneJobId") or "").strip()
    project_id   = (body.get("projectId") or "default").strip() or "default"
    include_pm   = _bool(body.get("includePm"), default=True)

    tenant_id = None
    session_id = "session_" + uuid.uuid4().hex[:16]

    try:
        # ---- Resolve tenant ----
        ut = dynamodb.Table(USER_TENANTS_TABLE).get_item(
            Key={"userId": user["userId"]}
        ).get("Item")
        if not ut:
            audit_log("OPENCODE_SESSION_START", user["userId"], None, False, {"error": "User has no tenant"})
            return resp(404, {"ok": False, "error": "User has no tenant", "buildId": BUILD_ID})
        tenant_id = ut["tenantId"]

        tenant = dynamodb.Table(TENANTS_TABLE).get_item(
            Key={"tenantId": tenant_id}
        ).get("Item")
        if not tenant or tenant.get("status") != "ACTIVE":
            audit_log("OPENCODE_SESSION_START", user["userId"], tenant_id, False, {"error": "Tenant inactive"})
            return resp(403, {"ok": False, "error": "Tenant inactive", "buildId": BUILD_ID})

        bucket                = (tenant.get("bucketName") or "").strip()
        tenant_workload_role  = (tenant.get("tenantWorkloadRoleArn") or "").strip()

        if not bucket or not tenant_workload_role:
            audit_log("OPENCODE_SESSION_START", user["userId"], tenant_id, False, {"error": "Tenant not fully provisioned"})
            return resp(500, {"ok": False, "error": "Tenant not fully provisioned", "buildId": BUILD_ID})

        # ---- Load clone job to find repo S3 prefix (optional) ----
        repo_prefix = ""
        repo_name   = "repo"

        if clone_job_id:
            clone_job = dynamodb.Table(JOBS_TABLE).get_item(
                Key={"tenantId": tenant_id, "jobId": clone_job_id}
            ).get("Item")
            if not clone_job:
                return resp(404, {"ok": False, "error": "Clone job not found", "buildId": BUILD_ID})
            if clone_job.get("type") not in ("clone",):
                return resp(400, {"ok": False, "error": "Job is not a clone job", "buildId": BUILD_ID})

            # repoPrefix is the worktree path (e.g. projects/.../snapshots/.../worktree)
            repo_prefix = (clone_job.get("repoPrefix") or "").strip()
            repo_name   = (clone_job.get("repoName") or "repo").strip()
            if not repo_prefix:
                return resp(500, {"ok": False, "error": "Clone job has no repoPrefix", "buildId": BUILD_ID})

        # PM files prefix - syncs the entire pm/ tree (manual uploads + Jira, etc.)
        pm_s3_prefix = f"projects/{project_id}/pm" if include_pm else ""

        # ---- Generate one-time session password ----
        # url-safe base64, 24 bytes -> 32 character string
        session_password = secrets.token_urlsafe(24)

        # ---- Build container environment overrides ----
        env_overrides = [
            {"name": "TENANT_ROLE_ARN",           "value": tenant_workload_role},
            {"name": "TENANT_BUCKET",              "value": bucket},
            {"name": "REPO_PREFIX",                "value": repo_prefix},
            {"name": "PM_S3_PREFIX",               "value": pm_s3_prefix},
            {"name": "OPENCODE_SERVER_PASSWORD",   "value": session_password},
            {"name": "BEDROCK_MODEL_ID",           "value": BEDROCK_MODEL_ID},
            {"name": "AWS_DEFAULT_REGION",         "value": AWS_REGION},
            {"name": "SESSION_ID",                 "value": session_id},
        ]

        task_def_arn = _get_task_def_arn()

        # enableExecuteCommand=True is required for SSM port forwarding.
        run = ecs_client.run_task(
            cluster=CLUSTER_ARN,
            taskDefinition=task_def_arn,
            launchType="FARGATE",
            enableExecuteCommand=True,
            networkConfiguration={
                "awsvpcConfiguration": {
                    "subnets": SUBNETS,
                    "securityGroups": [SECURITY_GROUP_ID],
                    "assignPublicIp": "DISABLED",
                }
            },
            overrides={
                "containerOverrides": [
                    {"name": CONTAINER_NAME, "environment": env_overrides}
                ]
            },
        )

        failures = run.get("failures") or []
        if failures:
            audit_log("OPENCODE_SESSION_START", user["userId"], tenant_id, False,
                      {"error": "ECS run_task failed", "failures": failures})
            return resp(500, {"ok": False, "error": "Failed to start OpenCode session",
                              "failures": failures, "buildId": BUILD_ID})

        task_arn = (run.get("tasks") or [{}])[0].get("taskArn", "")

        # ---- Persist session in JOBS_TABLE ----
        dynamodb.Table(JOBS_TABLE).put_item(Item={
            "tenantId":       tenant_id,
            "jobId":          session_id,
            "type":           "opencode_session",
            "status":         "SUBMITTED",
            "createdAt":      now_iso(),
            "createdBy":      user["userId"],
            "projectId":      project_id,
            "cloneJobId":     clone_job_id,
            "repoName":       repo_name,
            "repoPrefix":     repo_prefix,
            "pmS3Prefix":     pm_s3_prefix,
            "bucketName":     bucket,
            "taskArn":        task_arn,
            "clusterArn":     CLUSTER_ARN,
            "taskDefArn":     task_def_arn,
            "containerName":  CONTAINER_NAME,
            "password":       session_password,
        })

        # Derive short task ID for connection instructions
        task_id = task_arn.split("/")[-1] if task_arn else "<taskId>"
        cluster_name = CLUSTER_ARN.split("/")[-1]

        connection_instructions = (
            "# 1. Wait ~30s for the task to reach RUNNING, then get the container runtime ID:\n"
            f"TASK_ID={task_id}\n"
            f"CLUSTER={cluster_name}\n"
            "CONTAINER_RT=$(aws ecs describe-tasks --cluster $CLUSTER --tasks $TASK_ID "
            "--query 'tasks[0].containers[0].runtimeId' --output text --region ca-central-1)\n\n"
            "# 2. Open SSM port-forward tunnel (runs in background):\n"
            "aws ssm start-session \\\n"
            "  --target \"ecs:${CLUSTER}_${TASK_ID}_${CONTAINER_RT}\" \\\n"
            "  --document-name AWS-StartPortForwardingSession \\\n"
            "  --parameters '{\"portNumber\":[\"4096\"],\"localPortNumber\":[\"4096\"]}' &\n"
            "sleep 3\n\n"
            "# 3. Connect with opencode:\n"
            "opencode attach http://localhost:4096 --password '<password from response>'"
        )

        audit_log("OPENCODE_SESSION_START", user["userId"], tenant_id, True, {
            "sessionId":  session_id,
            "taskArn":    task_arn,
            "repoName":   repo_name,
            "cloneJobId": clone_job_id,
            "buildId":    BUILD_ID,
        })

        return resp(202, {
            "ok":           True,
            "buildId":      BUILD_ID,
            "sessionId":    session_id,
            "taskArn":      task_arn,
            "taskId":       task_id,
            "clusterName":  cluster_name,
            "repoName":     repo_name,
            "password":     session_password,
            "port":         4096,
            "status":       "SUBMITTED",
            "connectionInstructions": connection_instructions,
        })

    except Exception as e:
        audit_log("OPENCODE_SESSION_START", user.get("userId", "unknown"), tenant_id, False,
                  {"error": "Unhandled exception", "detail": str(e), "buildId": BUILD_ID})
        return resp(500, {"ok": False, "error": "Internal Server Error", "buildId": BUILD_ID})
