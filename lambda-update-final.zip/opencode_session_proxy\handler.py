# lambdas/opencode_session_proxy/handler.py
#
# Proxy HTTP requests to OpenCode Fargate task
#
# Flow:
#   1. Validate Cognito JWT -> get tenantId
#   2. Extract sessionId from URL path
#   3. Look up session in JOBS_TABLE -> get taskArn
#   4. Get task's private IP from ECS
#   5. Forward HTTP request to http://task-ip:4096/*
#   6. Include Basic Auth (opencode:password from session)
#   7. Return response to client
#
# Supports:
#   POST /session              - create session (direct to task)
#   GET /session/{id}          - get session status
#   POST /session/{id}/message - submit message/prompt
#   GET /event/subscribe       - subscribe to events (SSE)
#   DELETE /session/{id}       - stop session

from __future__ import annotations

import json
import os
import base64
import re
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen
from urllib.error import URLError
from io import BytesIO

import boto3

from common import resp, get_user, audit_log, is_options

def resp_with_cors(status_code, body):
    """Return response with CORS headers."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET,POST,DELETE,OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
        },
        "body": json.dumps(body),
    }

AWS_REGION          = os.environ.get("AWS_DEFAULT_REGION", "ca-central-1")
BUILD_ID            = os.environ.get("BUILD_ID", "unknown")

TENANTS_TABLE       = os.environ["TENANTS_TABLE"]
USER_TENANTS_TABLE  = os.environ["USER_TENANTS_TABLE"]
JOBS_TABLE          = os.environ["JOBS_TABLE"]

# OpenCode server port (from Dockerfile: ENV PORT=4096)
OPENCODE_PORT       = 4096

dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
ecs_client = boto3.client("ecs", region_name=AWS_REGION)


def _get_task_private_ip(task_arn: str) -> str | None:
    """Get private IP of an ECS task from its ARN."""
    try:
        # Extract cluster and task ID from ARN
        # arn:aws:ecs:region:account:task/cluster-name/task-id
        parts = task_arn.split("/")
        if len(parts) < 3:
            return None

        cluster_name = parts[-2]
        task_id = parts[-1]

        # Describe the task
        response = ecs_client.describe_tasks(
            cluster=cluster_name,
            tasks=[task_arn],
            include=["FULL"]
        )

        if not response["tasks"]:
            return None

        task = response["tasks"][0]

        # Get private IP from attachments
        if "attachments" in task:
            for attachment in task["attachments"]:
                if attachment.get("type") == "ElasticNetworkInterface":
                    for detail in attachment.get("details", []):
                        if detail.get("name") == "privateIPv4Address":
                            return detail.get("value")

        return None
    except Exception as e:
        print(f"Error getting task IP: {e}")
        return None


def _forward_request(
    method: str,
    path: str,
    task_ip: str,
    password: str,
    headers: dict | None = None,
    body: str | None = None,
    query_string: str | None = None,
) -> tuple[int, dict, str]:
    """Forward HTTP request to OpenCode server and return response."""
    try:
        # Build target URL
        url = f"http://{task_ip}:{OPENCODE_PORT}{path}"
        if query_string:
            url += f"?{query_string}"

        # Build auth header
        auth_header = base64.b64encode(f"opencode:{password}".encode()).decode()

        # Prepare headers
        req_headers = headers or {}
        req_headers["Authorization"] = f"Basic {auth_header}"

        # Remove hop-by-hop headers
        hop_by_hop = {"connection", "keep-alive", "transfer-encoding", "upgrade", "te", "trailer"}
        req_headers = {k: v for k, v in req_headers.items() if k.lower() not in hop_by_hop}

        # Forward request with urllib
        body_bytes = body.encode() if body else None
        req = Request(url, data=body_bytes, headers=req_headers, method=method)

        try:
            response = urlopen(req, timeout=30)
            status = response.status
            resp_body = response.read().decode()
            resp_headers = dict(response.headers)
        except URLError as e:
            if hasattr(e, 'code'):
                status = e.code
                resp_body = e.read().decode() if hasattr(e, 'read') else str(e)
                resp_headers = dict(e.headers) if hasattr(e, 'headers') else {}
            else:
                return 502, {}, f"Bad gateway: {str(e)}"

        # Filter hop-by-hop headers from response
        resp_headers = {
            k: v for k, v in resp_headers.items()
            if k.lower() not in hop_by_hop
        }

        return status, resp_headers, resp_body

    except TimeoutError:
        return 504, {}, "Gateway timeout"
    except Exception as e:
        print(f"Forwarding error: {e}")
        return 500, {}, f"Internal error: {str(e)}"


def main(event, context):
    if is_options(event):
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET,POST,DELETE,OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type,Authorization",
            },
            "body": json.dumps({"ok": True, "buildId": BUILD_ID})
        }

    user = get_user(event)
    print(f"DEBUG: user from get_user = {user}")
    print(f"DEBUG: Authorization header = {event.get('headers', {}).get('authorization', 'NOT FOUND')}")
    if not user.get("userId"):
        audit_log("OPENCODE_PROXY", "anonymous", None, False, {"error": "Unauthorized"})
        return resp_with_cors(401, {"ok": False, "error": "Unauthorized", "buildId": BUILD_ID})

    try:
        # Get tenant
        ut = dynamodb.Table(USER_TENANTS_TABLE).get_item(
            Key={"userId": user["userId"]}
        ).get("Item")
        if not ut:
            audit_log("OPENCODE_PROXY", user["userId"], None, False, {"error": "User has no tenant"})
            return resp_with_cors(404, {"ok": False, "error": "User has no tenant", "buildId": BUILD_ID})

        tenant_id = ut["tenantId"]

        # Extract method, path, and query string from event
        method = event.get("requestContext", {}).get("http", {}).get("method", "GET")
        raw_path = event.get("rawPath", "")
        raw_query = event.get("rawQueryString", "")

        # Extract sessionId from path (e.g., /session/abc123 -> abc123)
        match = re.match(r"^/session(?:/([^/]+))?(?:/.*)?$", raw_path)
        if not match:
            return resp_with_cors(400, {"ok": False, "error": "Invalid session path", "buildId": BUILD_ID})

        session_id = match.group(1)  # None if just /session

        # Special case: GET /session (list sessions) - return empty list
        if method == "GET" and raw_path == "/session":
            return resp_with_cors(200, {"data": []})

        # Special case: POST /session (create new session)
        # Get cloneJobId from request body
        request_body = {}
        if method == "POST" and event.get("body"):
            try:
                if event.get("isBase64Encoded"):
                    import base64
                    request_body = json.loads(base64.b64decode(event["body"]).decode())
                else:
                    request_body = json.loads(event["body"])
            except:
                pass

        if method == "POST" and raw_path == "/session":
            clone_job_id = (request_body.get("cloneJobId") or "").strip()

            # If no cloneJobId provided, optionally get the most recent completed clone job
            if not clone_job_id:
                try:
                    jobs_table = dynamodb.Table(JOBS_TABLE)
                    response = jobs_table.query(
                        IndexName="tenantId-createdAt-index",
                        KeyConditionExpression="tenantId = :tid",
                        FilterExpression="jobType = :type AND #status = :status",
                        ExpressionAttributeNames={"#status": "status"},
                        ExpressionAttributeValues={
                            ":tid": tenant_id,
                            ":type": "clone",
                            ":status": "SUCCEEDED"
                        },
                        ScanIndexForward=False,
                        Limit=1,
                    )
                    if response.get("Items"):
                        clone_job_id = response["Items"][0]["jobId"]
                except:
                    pass

            # Build session creation payload (cloneJobId is optional)
            session_payload = {}
            if clone_job_id:
                session_payload["cloneJobId"] = clone_job_id

            # Forward to opencode_session_start Lambda via direct invocation
            lambda_client = boto3.client("lambda", region_name=AWS_REGION)
            try:
                session_resp = lambda_client.invoke(
                    FunctionName="autodoc-control-plane-api-OpencodeSessionStartFn",
                    InvocationType="RequestResponse",
                    Payload=json.dumps({
                        "requestContext": event.get("requestContext", {}),
                        "body": json.dumps(session_payload)
                    })
                )

                status_code = session_resp.get("StatusCode")
                print(f"DEBUG: opencode_session_start response status: {status_code}")

                if status_code == 200:
                    payload = json.loads(session_resp.get("Payload", "{}").read())
                    print(f"DEBUG: opencode_session_start response payload: {payload}")
                    return payload  # Return Lambda response directly
                else:
                    # Log the error response for debugging
                    error_payload = session_resp.get("Payload", "{}").read()
                    print(f"DEBUG: opencode_session_start error response: {error_payload}")
                    return resp_with_cors(500, {
                        "ok": False,
                        "error": f"Failed to create session (status: {status_code})",
                        "buildId": BUILD_ID
                    })
            except Exception as e:
                print(f"Error invoking opencode_session_start: {e}")
                audit_log("OPENCODE_PROXY", user["userId"], tenant_id, False, {
                    "error": f"Failed to create session: {str(e)}"
                })
                return resp_with_cors(500, {
                    "ok": False,
                    "error": "Failed to create session",
                    "buildId": BUILD_ID
                })

        # All other requests require valid sessionId
        if not session_id:
            return resp_with_cors(400, {"ok": False, "error": "sessionId required", "buildId": BUILD_ID})

        # Look up session in JOBS_TABLE
        jobs_table = dynamodb.Table(JOBS_TABLE)
        session_record = jobs_table.get_item(Key={"jobId": session_id}).get("Item")

        if not session_record:
            audit_log("OPENCODE_PROXY", user["userId"], tenant_id, False, {
                "error": f"Session not found: {session_id}"
            })
            return resp_with_cors(404, {"ok": False, "error": "Session not found", "buildId": BUILD_ID})

        # Verify session belongs to user's tenant
        if session_record.get("tenantId") != tenant_id:
            audit_log("OPENCODE_PROXY", user["userId"], tenant_id, False, {
                "error": f"Unauthorized: session {session_id} belongs to different tenant"
            })
            return resp_with_cors(403, {"ok": False, "error": "Forbidden", "buildId": BUILD_ID})

        # Get task ARN and password
        task_arn = session_record.get("taskArn")
        password = session_record.get("password")

        if not task_arn or not password:
            audit_log("OPENCODE_PROXY", user["userId"], tenant_id, False, {
                "error": f"Session missing taskArn or password: {session_id}"
            })
            return resp_with_cors(500, {"ok": False, "error": "Session configuration error", "buildId": BUILD_ID})

        # Get task's private IP
        task_ip = _get_task_private_ip(task_arn)
        if not task_ip:
            audit_log("OPENCODE_PROXY", user["userId"], tenant_id, False, {
                "error": f"Could not determine task IP for {task_arn}"
            })
            return resp_with_cors(502, {"ok": False, "error": "Could not reach session task", "buildId": BUILD_ID})

        # Get request body if present
        body = None
        if method in ("POST", "PUT"):
            if event.get("body"):
                body = event["body"]
                if event.get("isBase64Encoded"):
                    import base64
                    body = base64.b64decode(body).decode()

        # Get headers
        headers = event.get("headers", {})

        # Forward request to OpenCode
        status, resp_headers, resp_body = _forward_request(
            method=method,
            path=raw_path,
            task_ip=task_ip,
            password=password,
            headers=headers,
            body=body,
            query_string=raw_query,
        )

        audit_log("OPENCODE_PROXY", user["userId"], tenant_id, True, {
            "method": method,
            "path": raw_path,
            "status": status,
            "sessionId": session_id,
        })

        # Add CORS headers to response
        resp_headers["Access-Control-Allow-Origin"] = "*"
        resp_headers["Access-Control-Allow-Methods"] = "GET,POST,DELETE,OPTIONS"
        resp_headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization"

        # Return response
        return {
            "statusCode": status,
            "headers": resp_headers,
            "body": resp_body,
            "isBase64Encoded": False,
        }

    except Exception as e:
        print(f"Error in proxy: {e}")
        audit_log("OPENCODE_PROXY", user.get("userId"), None, False, {"error": str(e)})
        return resp_with_cors(500, {"ok": False, "error": "Internal server error", "buildId": BUILD_ID})
